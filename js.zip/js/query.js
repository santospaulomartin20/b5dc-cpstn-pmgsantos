$(window).scroll(function() {
  if ($(window).scrollTop()) {
    $('nav').addClass('shrink');
 	$('nav').removeClass('hideme');
  } else {
    $('nav').removeClass('shrink');
  }
});

$('#desH1').hover(function() {
	if ($('#desH1').hover()) {
	$('h1').addClass('animated rubberBand');
	} else {
		$('h1').removeClass('animated rubberBand');
	}
});

$(window).hover(function() {
	if ($(window).scrollTop()) {
	$('h1').removeClass('animated rubberBand');
	} else {
		
	}
});
$('#hello').hover(function() {
	if ($('#hello').hover()) {
	$('.cont1').addClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
	$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{ 
	}
});
$('#hello1').hover(function() {
	if ($('#hello1').hover()) {
	$('.cont1').addClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#hello2').hover(function() {
	if ($('#hello2').hover()) {
	$('.cont1').addClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#hello3').hover(function() {
	if ($('#hello3').hover()) {
	$('.cont1').addClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#hello4').hover(function() {
	if ($('#hello4').hover()) {
	$('.cont1').addClass('bgImageCont4');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#pasta1').hover(function() {
	if ($('#pasta1').hover()) {
	$('.cont1').addClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#pasta2').hover(function() {
	if ($('#pasta2').hover()) {
	$('.cont1').addClass('psImageCon2');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#pasta3').hover(function() {
	if ($('#pasta3').hover()) {
	$('.cont1').addClass('psImageCon3');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#pasta4').hover(function() {
	if ($('#pasta4').hover()) {
	$('.cont1').addClass('psImageCon4');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#pasta5').hover(function() {
	if ($('#pasta5').hover()) {
	$('.cont1').addClass('psImageCon5');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon1');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');

} else	{
	}
});
$('#chicken1').hover(function() {
	if ($('#chicken1').hover()) {
	$('.cont1').addClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#chicken2').hover(function() {
	if ($('#chicken2').hover()) {
	$('.cont1').addClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#chicken3').hover(function() {
	if ($('#chicken3').hover()) {
	$('.cont1').addClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#chicken4').hover(function() {
	if ($('#chicken4').hover()) {
	$('.cont1').addClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#chicken5').hover(function() {
	if ($('#chicken5').hover()) {
	$('.cont1').addClass('ckImageCon5');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#bev1').hover(function() {
	if ($('#bev1').hover()) {
	$('.cont1').addClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#bev2').hover(function() {
	if ($('#bev2').hover()) {
	$('.cont1').addClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#bev3').hover(function() {
	if ($('#bev3').hover()) {
	$('.cont1').addClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#bev4').hover(function() {
	if ($('#bev4').hover()) {
	$('.cont1').addClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#bev5').hover(function() {
	if ($('#bev5').hover()) {
	$('.cont1').addClass('bvImageCon5');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');

} else	{
	}
});
$('#desserts1').hover(function() {
	if ($('#desserts1').hover()) {
	$('.cont1').addClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{
	}
});
$('#desserts2').hover(function() {
	if ($('#desserts2').hover()) {
	$('.cont1').addClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{
	}
});
$('#desserts3').hover(function() {
	if ($('#desserts3').hover()) {
	$('.cont1').addClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{
	}
});
$('#desserts4').hover(function() {
	if ($('#desserts4').hover()) {
	$('.cont1').addClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{
	}
});
$('#desserts5').hover(function() {
	if ($('#desserts5').hover()) {
	$('.cont1').addClass('dsImageCon5');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
} else	{
	}
});
$('#etc1').hover(function() {
	if ($('#etc1').hover()) {
	$('.cont1').addClass('etImageCon1');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');


} else	{
	}
});
$('#etc2').hover(function() {
	if ($('#etc2').hover()) {
	$('.cont1').addClass('etImageCon2');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');


} else	{
	}
});
$('#etc3').hover(function() {
	if ($('#etc3').hover()) {
	$('.cont1').addClass('etImageCon3');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');


} else	{
	}
});
$('#etc4').hover(function() {
	if ($('#etc4').hover()) {
	$('.cont1').addClass('etImageCon4');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('etImageCon5');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');


} else	{
	}
});
$('#etc5').hover(function() {
	if ($('#etc5').hover()) {
	$('.cont1').addClass('etImageCon5');
	$('.cont1').removeClass('etImageCon2');
	$('.cont1').removeClass('etImageCon3');
	$('.cont1').removeClass('etImageCon4');
	$('.cont1').removeClass('etImageCon1');
	$('.cont1').removeClass('psImageCon1');
	$('.cont1').removeClass('psImageCon2');
	$('.cont1').removeClass('psImageCon3');
	$('.cont1').removeClass('psImageCon4');
	$('.cont1').removeClass('psImageCon5');
		$('.cont1').removeClass('ckImageCon1');
	$('.cont1').removeClass('ckImageCon2');
	$('.cont1').removeClass('ckImageCon3');
	$('.cont1').removeClass('ckImageCon4');
	$('.cont1').removeClass('ckImageCon5');
		$('.cont1').removeClass('bgImageCont');
	$('.cont1').removeClass('bgImageCont1');
	$('.cont1').removeClass('bgImageCont2');
	$('.cont1').removeClass('bgImageCont3');
	$('.cont1').removeClass('bgImageCont4');
		$('.cont1').removeClass('bvImageCon1');
	$('.cont1').removeClass('bvImageCon2');
	$('.cont1').removeClass('bvImageCon3');
	$('.cont1').removeClass('bvImageCon4');
	$('.cont1').removeClass('bvImageCon5');
	$('.cont1').removeClass('dsImageCon1');
	$('.cont1').removeClass('dsImageCon2');
	$('.cont1').removeClass('dsImageCon3');
	$('.cont1').removeClass('dsImageCon4');
	$('.cont1').removeClass('dsImageCon5');
} else	{
	}
});

// $(document).ready(function(){
//     $('[data-toggle="tooltip"]').tooltip();   
// });

$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});


function animationHover(element, animation){
    h1 = $(h1);
    h1.hover(
        function() {
            h1.addClass('animated ' + wobble);        
        },
        function(){
            //wait for animation to finish before removing classes
            window.setTimeout( function(){
                h1.removeClass('animated ' + wobble);
            }, 2000);         
        });
}